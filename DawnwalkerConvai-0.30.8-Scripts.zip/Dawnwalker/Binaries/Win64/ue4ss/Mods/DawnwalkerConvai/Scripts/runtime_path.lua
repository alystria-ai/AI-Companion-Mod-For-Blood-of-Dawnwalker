local source=debug.getinfo(1,'S').source:gsub('^@',''):gsub('\\','/')
local scripts=assert(source:match('^(.*)/[^/]+$'),'Cannot locate mod Scripts folder')
local mod=assert(scripts:match('^(.*)/Scripts$'),'Unexpected mod folder')
local root=mod..'/Payload/runtime'
local function write(name,value)local f=assert(io.open(root..'/'..name,'w'));f:write(value);f:close()end
write('node-path.txt',mod..'/Payload/node/node.exe')
write('mod-directory.txt',mod)
return root
